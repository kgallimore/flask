from setuptools import setup

setup(
   name='flask',
   version='0.5',
   description='Does nothing',
   author='Keith Gallimore',
   install_requires=['opencv-python', 'flask', 'numpy',]
)
