import camera_multicv
from importlib import import_module

from flask import Flask, render_template, Response, send_from_directory, request


def gen(camera):
    while running_status:
        frame = camera.get_frame()
        if frame is not None:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    camera.set_run(False)


# Initialize flask variables
app = Flask(__name__, static_url_path='/static')
running_status = True


@app.route('/')
def index():
    return render_template('charts.html')


@app.route('/cameras')
def cameras():
    return render_template('cameras.html')


@app.route('/feed/<device>')
def multi_video_feed(device):
    """Video streaming route. Put this in the src attribute of an img tag."""
    camera_stream = import_module('camera_multicv').BaseCamera
    camera_stream.set_video_source(int(device))
    return Response(gen(camera_stream(int(device))), mimetype='multipart/x-mixed-replace; boundary=frame')


if __name__ == "__main__":
    try:
        app.run(host='0.0.0.0', port=80, debug=True, threaded=True)
    except KeyboardInterrupt:
        running_status = False
        exit(0)
